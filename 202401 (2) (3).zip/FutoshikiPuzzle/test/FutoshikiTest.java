/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import futoshikipuzzle.Futoshiki;
import futoshikipuzzle.TextGame;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author esw22
 */
public class FutoshikiTest {

    Futoshiki illegalPuzzle, duplicateRowPuzzle, duplicateColumnPuzzle,
            invalidColumnPuzzle, invalidRowPuzzle;

    Futoshiki filledPuzzle;

    static final String emptyPuzzleString = String.format(
            "%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                   ",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                   ",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                   ",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                   ",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---");

    static final String filledPuzzleString = String.format(
            "%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n%s%n",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                   ",
            "--- --- --- --- ---",
            "| | | | | | | |>| |",
            "--- --- --- --- ---",
            " V                 ",
            "--- --- --- --- ---",
            "| | | | | | | | | |",
            "--- --- --- --- ---",
            "                 ^ ",
            "--- --- --- --- ---",
            "| | | |<| | | | | |",
            "--- --- --- --- ---",
            "                 ^ ",
            "--- --- --- --- ---",
            "|4|<| | | |<| | | |",
            "--- --- --- --- ---");

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        duplicateRowPuzzle = new Futoshiki();
        duplicateRowPuzzle.setSquare(3, 3, 5);
        duplicateRowPuzzle.setSquare(3, 4, 5);
        duplicateColumnPuzzle = new Futoshiki();
        duplicateColumnPuzzle.setSquare(3, 1, 4);
        duplicateColumnPuzzle.setSquare(4, 1, 4);
        invalidRowPuzzle = new Futoshiki();
        invalidRowPuzzle.setSquare(0, 0, 5);
        invalidRowPuzzle.setSquare(0, 1, 1);
        invalidRowPuzzle.setRowConstraint(0, 0, "<");
        invalidColumnPuzzle = new Futoshiki();
        invalidColumnPuzzle.setColumnConstraint(4, 3, ">");
        invalidColumnPuzzle.setSquare(3, 4, 1);
        invalidColumnPuzzle.setSquare(4, 4, 2);
        // 1 du row, 2 dup colum, 1 invalid row, 2 invalid chained col
        illegalPuzzle = new Futoshiki();
                illegalPuzzle.setColumnConstraint(4, 2, ">");
        illegalPuzzle.setSquare(2, 4, 1);
        illegalPuzzle.setColumnConstraint(4, 3, ">");
        illegalPuzzle.setSquare(3, 4, 2);
        illegalPuzzle.setSquare(4, 4, 3);
        illegalPuzzle.setSquare(2, 2, 5);
        illegalPuzzle.setSquare(1, 2, 5);
        illegalPuzzle.setRowConstraint(0, 0, "<");
        illegalPuzzle.setSquare(0, 0, 5);
        illegalPuzzle.setSquare(0, 1, 1);
        illegalPuzzle.setSquare(0, 4, 1);
        //sets up a legal Futoshiki puzzle
        filledPuzzle = new Futoshiki();
        filledPuzzle.setColumnConstraint(0, 1, ">");
        filledPuzzle.setRowConstraint(4, 0, "<");
        filledPuzzle.setRowConstraint(4, 2, "<");
        filledPuzzle.setColumnConstraint(4, 3, "<");
        filledPuzzle.setColumnConstraint(4, 2, "<");
        filledPuzzle.setRowConstraint(3, 1, "<");
        filledPuzzle.setRowConstraint(1, 3, ">");

        filledPuzzle.setSquare(4, 0, 4);
    }

    @After
    public void tearDown() {
    }

    @Test
    public void printEmptyTest() {

        Futoshiki fs = new Futoshiki();
        assertEquals(emptyPuzzleString, fs.displayString());

    }

    @Test
    public void printFilledTest() {
        assertEquals(filledPuzzleString, filledPuzzle.displayString());
    }

    @Test
    public void problemTest() {

        assertTrue(filledPuzzle.isLegal());
        assertEquals(0, filledPuzzle.getProblems().size());
        assertTrue(!invalidRowPuzzle.isLegal());
        assertEquals(1, invalidRowPuzzle.getProblems().size());
        assertTrue(!invalidColumnPuzzle.isLegal());
        assertEquals(1, invalidColumnPuzzle.getProblems().size());
        assertTrue(!duplicateRowPuzzle.isLegal());
        assertEquals(1, duplicateRowPuzzle.getProblems().size());
        assertTrue(duplicateRowPuzzle.getProblems().get(0).contains("row"));
        assertTrue(!duplicateColumnPuzzle.isLegal());
        assertEquals(1, duplicateColumnPuzzle.getProblems().size());

        assertTrue(duplicateColumnPuzzle.getProblems().get(0).contains("column"));

        assertTrue(!illegalPuzzle.isLegal());
        assertEquals(6, illegalPuzzle.getProblems().size());
    }
    
    @Test
    public void testRandomPuzzle() {
        boolean foundGreater = false;
        boolean foundLesser = false;
        // This is a one off test.  One might argue that this is a random 
        // method, so should be called multiple times.  However, given the
        // fill occupancy used, there are multiple collisions with very
        // high probability
        Futoshiki fs = new Futoshiki(5);
        fs.fillPuzzle(10, 10, 10);

        String s = fs.displayString();
        int[] counter = new int[3];
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '<' || s.charAt(i) == '^') {
                foundLesser = true;
            } else if (s.charAt(i) == '>' || s.charAt(i) == 'V') {
                foundGreater = true;
            }
            switch (s.charAt(i)) {
                case '1':
                case '2':
                case '3':
                case '4':
                case '5': {
                    counter[0]++;
                    break;
                }
                case '<':
                case '>': {
                    counter[1]++;

                    break;
                }
                case 'V':
                case '^': {
                    counter[2]++;
                    break;
                }
            }
        }      
        assertTrue(foundLesser);
        assertTrue(foundGreater);
        for (int count : counter) {
            assertEquals(10, count);
        }

    }
    
    @Test
    public void testTextGame() {
        String commandTest = "Mark 1 0 5\n Clear 0 4\nQUIT\n";
        TextGame tg = new TextGame();
        tg.setPuzzle(filledPuzzle);
        InputStream is = new ByteArrayInputStream(commandTest.getBytes());
        tg.setInputStream(is);
        tg.play();
        assertEquals(5,filledPuzzle.getSquare(0,1).getValue());
        assertEquals(0,filledPuzzle.getSquare(4, 0).getValue());
    }
}
