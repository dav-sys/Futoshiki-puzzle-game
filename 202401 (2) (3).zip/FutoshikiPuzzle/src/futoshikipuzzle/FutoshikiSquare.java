/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

/**
 *
 
 */
public abstract class FutoshikiSquare
{
    public abstract boolean isFilled();
    public abstract String getSymbol();

    public abstract void setValue(int value);

    public abstract int getValue();
}