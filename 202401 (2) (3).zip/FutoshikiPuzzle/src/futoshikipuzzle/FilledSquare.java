/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

/**
 *
 * 
 */
public class FilledSquare extends FutoshikiSquare
{
    private int value;
    
    public FilledSquare(int val)
    {
        value = val;
    }
    
    @Override
    public String getSymbol()
    {
        return "" + value;
    }

    @Override
    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public boolean isFilled()
    {
        return true;
    }
}

