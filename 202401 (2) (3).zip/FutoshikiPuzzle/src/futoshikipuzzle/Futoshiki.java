/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

/**
 *
 * 
 */
import java.util.ArrayList;
import java.util.List;

/**

 
 *
 * @author Ian Wakeman
 * @version 1.0
 */
public class Futoshiki
{

    public static  void main(String[] args){
        Futoshiki start = new Futoshiki();
    }

    //constant to specify size of puzzle
    public static final int DEFAULTGRIDSIZE = 5;
    
    private final FutoshikiSquare[][] squares;
    private final Constraint[][] rowConstraints;
    private final Constraint[][] columnConstraints;
    
    public Futoshiki()
    {
        squares = new FutoshikiSquare[DEFAULTGRIDSIZE][DEFAULTGRIDSIZE];
        rowConstraints = new Constraint[DEFAULTGRIDSIZE][DEFAULTGRIDSIZE - 1];
        columnConstraints = new Constraint[DEFAULTGRIDSIZE][DEFAULTGRIDSIZE - 1];
        
        //set up the  initial grid of empty squares
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            for (int column = 0; column < DEFAULTGRIDSIZE; column++) {
                squares[row][column] = new EmptyConstraint();
            }
        }
        
        //set up the initial row constraints 
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            for (int column = 0; column < DEFAULTGRIDSIZE - 1; column++) {
                rowConstraints[row][column] = new NoConstraint(row, column, row, column + 1, this);
            }
        }
        
        //set up the  initial column constraints 
        for (int column = 0; column < DEFAULTGRIDSIZE; column++) {
            for (int row = 0; row < DEFAULTGRIDSIZE - 1; row++) {
                columnConstraints[column][row] = new NoConstraint(row, column, row + 1, column, this);
            }
        }
        FillPuzzle();
        new FutoshikiGUI(this, DEFAULTGRIDSIZE);
    }

    private void FillPuzzle(){
        setSquare(0,2,3);
        setRowConstraint(0,2,">");

        setColumnConstraint(0,0,">");
        setColumnConstraint(2,0,">");
        setColumnConstraint(3,0,">");

        setSquare(1,1,2);

        setRowConstraint(2,0,">");

        setColumnConstraint(0,2,"<");
        setColumnConstraint(1,2,"<");
        setColumnConstraint(2,2,"^");
        setColumnConstraint(4,2,"<");

        setSquare(3,4,4);

        setColumnConstraint(0,3, "v");

        setSquare(4,2,1);
        setRowConstraint(4,1,">");
    }
    
        public void displayEasy(){
        setSquare(0,1,3);
        setRowConstraint(0,2,"<");

        setColumnConstraint(4,0,"<");
        setColumnConstraint(2,0,">");
        setColumnConstraint(3,0,"^");

        setSquare(2,2,2);

        setRowConstraint(2,0,">");

        setColumnConstraint(2,2,"V");
        setColumnConstraint(1,2,">");
        setColumnConstraint(2,2,"<");
        setColumnConstraint(4,2,"^");

        setSquare(2,1,4);

        setColumnConstraint(0,3, ">");

        setSquare(4,2,1);
        setRowConstraint(4,1,">");
    }
      
        public void displayHard(){
        setSquare(0,1,3);
        setRowConstraint(0,2,">");

        setColumnConstraint(4,0,"<");
        setColumnConstraint(2,0,"<");
        setColumnConstraint(3,0,">");

        setSquare(1,2,2);

        setRowConstraint(2,0,">");

        setColumnConstraint(2,2,"V");
        setColumnConstraint(1,2,">");
        setColumnConstraint(2,2,"<");
        setColumnConstraint(4,2,"^");

        setSquare(2,1,4);

        setColumnConstraint(0,3, ">");

        setSquare(4,2,1);
        setRowConstraint(4,1,">");
    }

        
        

    public void emptySquares(){
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            for (int column = 0; column < DEFAULTGRIDSIZE; column++) {
                squares[row][column] = new EmptyConstraint();
            }
        }
    }

    public void setSquare(int col, int row, int val)
    {
        squares[col][row] = new FilledSquare(val);
    }
    
    public void setRowConstraint(int row, int col, String relation)
    {
        if (relation.equals("<")) {
            rowConstraints[row][col] = new LessThanConstraint(row, col, row, col + 1, this);
        }
        else if (relation.equals(">")) {
            rowConstraints[row][col] = new GreaterThanConstraint(row, col, row, col + 1, this);
        }
    }
    
    public void setColumnConstraint(int col, int row, String relation)
    {
        if (relation.equals("<")) {
            columnConstraints[col][row] = new LessThanConstraint(row, col, row + 1, col, this);
        }
        else if (relation.equals(">")) {
            columnConstraints[col][row] = new GreaterThanConstraint(row, col, row + 1, col , this);
        }
    }
    
    public FutoshikiSquare getSquare(int row, int col)
    {
        return squares[row][col];
    }
    

       /********************************************************************
     
     ********************************************************************/
   
 
    private String printTopBottom()
    {
        String s = "";
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            s += "---";
            if(col < (DEFAULTGRIDSIZE-1)) {
                s += " ";
            }
        }
        return s + "\n";
    }
    
    
     private String drawColumnConstraints(int row) 
    {
            String s = " ";
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
             s += columnConstraints[col][row].getSymbol() + " ";
                     if(col < (DEFAULTGRIDSIZE-1)) {
                s += "  ";
            }
        }

        return s + "\n";   
    }

     public String displaystring()
    {
        String s = "";
        for (int row = 0; row < DEFAULTGRIDSIZE - 1; row++) {
            s += drawRow(row);
            s += drawColumnConstraints(row);
        }
        s += drawRow(DEFAULTGRIDSIZE - 1);
        return s;
    }
   
    
    private String drawRow(int row) 
    {
        String s = printTopBottom();
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            s += "|" + squares[row][col].getSymbol() + "|";   
            if (col < DEFAULTGRIDSIZE - 1) {
                s += rowConstraints[row][col].getSymbol();
            }
        }
        return s + "\n" + printTopBottom();
    }

    private boolean checkEmpty(int row, int col)
    {
        return !squares[row][col].isFilled();
    }
    
    
    
    private boolean checkRowDuplicates(int row)
    {
        boolean[] found = new boolean[DEFAULTGRIDSIZE + 1]; 
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            if (!checkEmpty(row,col)) {
                int val = ((FilledSquare)squares[row][col]).getValue();
                if (!isIllegalValue(val)) {
                    if (found[val]) {
                        return false;
                    }
                    else {
                        found[val] = true;
                    }
                }
            }
        }
        return true;
    }
    
    private List<String> rowDuplicateProblems(int row)
    {
        ArrayList<String> result = new ArrayList();
        boolean[] found = new boolean[DEFAULTGRIDSIZE + 1]; //one longer as numbers go up to  the GRIDSIZE
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            if (!checkEmpty(row,col)) {
                int val = ((FilledSquare)squares[row][col]).getValue();
                if (!isIllegalValue(val)) {
                    if (found[val]) {
                        result.add("Duplicate entry " + val + " on row " + row + "\n");
                    }
                    else {
                        found[val] = true;
                    }
                }
            }
        }
        return result;
    }
    
    private boolean checkColumnDuplicates(int col)
    {
        boolean[] found = new boolean[DEFAULTGRIDSIZE + 1]; //one longer as numbers go up to the GRIDSIZE
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            if (!checkEmpty(row,col)) {
                int val = ((FilledSquare)squares[row][col]).getValue();
                if (!isIllegalValue(val)) {
                    if (found[val]) {
                        return false;
                    }
                    else {
                        found[val] = true;
                    }
                }
            }
        }
        return true;
    }
    
    private List<String> columnDuplicateProblems(int col)
    {
        ArrayList<String> result = new ArrayList();
        boolean[] found = new boolean[DEFAULTGRIDSIZE + 1]; //one longer as numbers go up to the  GRIDSIZE
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            if (!checkEmpty(row,col)) {
                int val = ((FilledSquare)squares[row][col]).getValue();
                if (!isIllegalValue(val)) {
                    if (found[val]) {
                        result.add("Duplicate entry " + val + " on column " + col + "\n");
                    }
                    else {
                        found[val] = true;
                    }
                }
            }
        }
        return result;
    }

    private boolean checkRowConstraints(int row)
    {
        for (int col = 0; col < DEFAULTGRIDSIZE - 1; col++) {
            Constraint constraint = rowConstraints[row][col];
            if (!constraint.isOK()) {
                return false;
            }
        }
        return true;
    }
    
    private List<String> rowConstraintProblems(int row)
    {
        ArrayList<String> result = new ArrayList();
        for (int col = 0; col < DEFAULTGRIDSIZE - 1; col++) {
            Constraint constraint = rowConstraints[row][col];
            if (!constraint.isOK()) {                   
                result.add("Row constraint violated at " + row + " "
                                            + col + " and " + row + " " + (col + 1) + "\n");
            }
        }
        return result;
    }
    
    private boolean checkColumnConstraints(int col)
    {
        for (int row = 0; row < DEFAULTGRIDSIZE - 1; row++) {
            Constraint constraint = columnConstraints[col][row];
            if (!constraint.isOK()) {
                return false;
            }
        }
        return true;
    }
    
    private List<String> columnConstraintProblems(int col)
    {   
        ArrayList<String> result = new ArrayList();
        for (int row = 0; row < DEFAULTGRIDSIZE - 1; row++) {
            Constraint constraint = columnConstraints[col][row];
            if (!constraint.isOK()) {
                result.add("Column constraint violated at " + row + " "
                                            + col + " and " + (row + 1) + " " + col + "\n");
            }
        }
        return result;
    }
    
    private boolean checkRow(int row)
    {
        return checkRowDuplicates(row) && checkRowConstraints(row);
    }
    
    private List<String> rowProblems(int row)
    {
        List<String> s = rowDuplicateProblems(row);
        s.addAll(rowConstraintProblems(row));
        return s;
    }
    
    private boolean checkColumn(int col)
    {
        return checkColumnDuplicates(col) && checkColumnConstraints(col);
    }
    
    private List<String> columnProblems(int col)
    {
        List<String> s = columnDuplicateProblems(col);
        s.addAll(columnConstraintProblems(col));
        return s;
    }
    
    private boolean validValues()
    {
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
                if (!checkEmpty(row,col)) {
                    int value = ((FilledSquare)squares[row][col]).getValue();
                    if (isIllegalValue(value)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    private boolean isIllegalValue(int val)
    {
        return (val < 1) || (val > DEFAULTGRIDSIZE);
    }
    
    private List<String> validValuesString()
    {
        ArrayList<String> result = new ArrayList();
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
                if (!checkEmpty(row,col)) {
                    int value = ((FilledSquare)squares[row][col]).getValue();
                    if (isIllegalValue(value)) {
                        result.add("Illegal value " + value + " at " + row + " " + col);
                    }
                }
            }
        }
        return result;
    }
    
  
    public List<String> getProblems()
    {
        List<String> result = validValuesString();
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            result.addAll(rowProblems(row));
        }
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            result.addAll(columnProblems(col));
        }
        return result;
    }

      public boolean isLegal()
    {
        boolean result = validValues();
        for (int row = 0; row < DEFAULTGRIDSIZE; row++) {
            result &= checkRow(row);
        }
        for (int col = 0; col < DEFAULTGRIDSIZE; col++) {
            result &= checkColumn(col);
        }
        return result;
    }
    
    
    public Constraint getColumnConstraint(int col, int row) {
        return columnConstraints[col][row];
    }

    public Constraint getRowConstraint(int row, int col) {
        return rowConstraints[row][col];
    }

    public void setEmpty(int col, int row) {
        squares[col][row] = new EmptyConstraint();
    }

    public FutoshikiSquare getEmpty(){
        for (int col = 0; col<DEFAULTGRIDSIZE;col++){
            for (int row = 0; row<DEFAULTGRIDSIZE;row++){
                if (!squares[col][row].isFilled()){
                    return squares[col][row];
                }
            }
        }
        return null;
    }

    public int[] getEmptyCords(){
        int[] cords = new int[2];
        for (int col = 0; col<DEFAULTGRIDSIZE;col++){
            for (int row = 0; row<DEFAULTGRIDSIZE;row++){
                if (!squares[col][row].isFilled()){
                    cords[0] = col;
                    cords[1] = row;
                    return cords;
                }
            }
        }
        return null;
    }

    public boolean solve(){
        if(!isLegal()){
            System.out.println("Grid is illegal.");
            return false;
        }
        if (isLegal() && getEmpty() == null){
            System.out.println("Finished.");
            return true;
        } else{
            int[] cords = getEmptyCords();
            for(int i = 1; i <= DEFAULTGRIDSIZE; i++){
                squares[cords[0]][cords[1]] = new FilledSquare(i);
                if (isLegal()){
                    System.out.println("Square (" + cords[0] + ", " + cords[1] + ") is now: " + i);
                    squares[cords[0]][cords[1]] = new FilledSquare(i);
                    solve();
                }
            }
                squares[cords[0]][cords[1]] = new EmptyConstraint();
        }
        return false;
    }
}