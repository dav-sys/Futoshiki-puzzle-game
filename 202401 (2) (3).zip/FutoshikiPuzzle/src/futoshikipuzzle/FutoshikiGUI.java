/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import java.awt.event.*;
import java.io.File;
import javax.swing.JFileChooser;


/**
 *
 *  
 */
public class FutoshikiGUI extends JFrame implements ActionListener {
    private Futoshiki futo;
    private int gridSize;
    private GUITextField[][] boxes;
    private JButton legal, solve, easy, hard, exit, save, load;
    private JTextArea issues;
    private JScrollPane scrollPane;
    private JPanel puzzlePanel = new JPanel();
    private JPanel userPanel = new JPanel();
    private JPanel issuePanel = new JPanel();
    private JPanel stuffPanel = new JPanel();

    public FutoshikiGUI(Futoshiki futo, int gridSize) {
        super("Futoshiki");
        this.futo = futo;
        this.gridSize = gridSize;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setResizable(false);

        this.setLayout(new GridLayout(2, 2));

        this.getContentPane().add(puzzlePanel);
        puzzlePanel.setBackground(Color.YELLOW);

        this.getContentPane().add(stuffPanel);

        stuffPanel.setLayout(new GridLayout(2, 2));

        stuffPanel.add(userPanel);
        userPanel.setBackground(Color.YELLOW);

        stuffPanel.add(issuePanel);
        issuePanel.setBackground(Color.YELLOW);

        issues = new JTextArea("Any issues will appear here.");
        issues.setEditable(false);
        issues.setOpaque(false);
        scrollPane = new JScrollPane(issues);
        scrollPane.setBackground(Color.WHITE);


        issuePanel.setBorder(BorderFactory.createTitledBorder("Issues"));
        issuePanel.add(scrollPane);

        puzzlePanel.setBorder(BorderFactory.createTitledBorder("Puzzle"));
        puzzlePanel.setLayout(new GridLayout(gridSize + 4, gridSize + 4, 0, 0));

        userPanel.setBorder(BorderFactory.createTitledBorder("User Actions"));
        easy = new JButton("Easy Puzzle");
        easy.setBackground(Color.WHITE);
        easy.addActionListener(this);
        easy.addActionListener(this);
        userPanel.add(easy);
        hard = new JButton("Hard Puzzle");
        hard.setBackground(Color.WHITE);
        hard.addActionListener(this);
        hard.addActionListener(this);
        userPanel.add(hard);
        legal = new JButton("Check");
        legal.setBackground(Color.WHITE);
        legal.addActionListener(this);
        userPanel.add(legal);
        solve = new JButton("Solve");
        solve.setBackground(Color.WHITE); 
        solve.addActionListener(this);
        userPanel.add(solve);
        save = new JButton("Save");
        save.setBackground(Color.WHITE);
        save.addActionListener(this);
        save.addActionListener(this);
        userPanel.add(save);
        load = new JButton("Open");
        load.setBackground(Color.WHITE);
        load.addActionListener(this);
        load.addActionListener(this);
        userPanel.add(load);
        exit = new JButton("Exit");
        exit.setBackground(Color.WHITE);
        exit.addActionListener(this);
        exit.addActionListener(this);
        userPanel.add(exit);


        boxes = new GUITextField[gridSize + 4][gridSize + 4];

        for (int col = 0; col <= gridSize + 3; col++) {
            for (int row = 0; row <= gridSize + 3; row++) {
                if (col % 2 == 0 && row % 2 == 0) {
                    boxes[col][row] = new GUITextField(col, row, futo, false, false);
                    puzzlePanel.add(boxes[col][row].getTextField());
                } else if (row % 2 == 0 && col % 2 != 0 && (col / 2) < 3) {
                    /*col constraints*/
                    boxes[col][row] = new GUITextField(col, row, futo, true, false);
                    puzzlePanel.add(boxes[col][row].getTextField());
                } else if (row % 2 != 0 && col % 2 == 0 && (row / 2) < 3) {
                    /*row constraint*/
                    boxes[col][row] = new GUITextField(col, row, futo, true, false);
                    puzzlePanel.add(boxes[col][row].getTextField());
                } else {
                    boxes[col][row] = new GUITextField(col, row, futo, false, true);
                    puzzlePanel.add(boxes[col][row].getTextField());

                }
            }
            pack();
            setVisible(true);
        }
    }

//exit puzzle, closes window    
public void CloseFrame(){
    super.dispose();
}


//double click button to save puzzle
private void SavePuzzle() {     
    save.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                JFileChooser saveFile = new JFileChooser();
                saveFile.showSaveDialog(null);
            }
        });

}

// double click button to open existing puzzle
private void loadPuzzle() {     
    load.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                JFileChooser openFile = new JFileChooser();
                openFile.showOpenDialog(null);
            }
        });

}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == legal) {
            if (futo.isLegal()) {
                JOptionPane.showMessageDialog(null, "Current configuration is valid.");
                issues.setText("Any issues will appear here.");
                issues.setEditable(false);
                scrollPane.setBounds(20,20,423,210);
                scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
            } else {
                JOptionPane.showMessageDialog(null, "Current configuration is invalid.");
                issues.setText("" + futo.getProblems());
                issues.setEditable(false);
                scrollPane.setBounds(20,20,423,210);
                scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
            }
        } else if (e.getSource() == solve) {
            futo.solve();
            for (int col = 0; col <= gridSize + 3; col++) {
                for (int row = 0; row <= gridSize + 3; row++) {
                    if (col % 2 == 0 && row % 2 == 0) {
                        boxes[col][row].getTextField();
                    }
                }
            }
            if (futo.isLegal()){
                JOptionPane.showMessageDialog(null, "Puzzle Solved!");
            }
        }
        else if (e.getSource() == easy) {
            futo.displayEasy();
        }
        else if (e.getSource() == hard) {
            futo.displayHard();
        }
        else if (e.getSource() == exit) {
            CloseFrame();
        }
        else if (e.getSource() == save) {
            SavePuzzle();
        }
        else if (e.getSource() == load) {
            loadPuzzle();
        }
        
       //System.out.println("new puzzle\n" + futo.displaystring());
    }
    
}