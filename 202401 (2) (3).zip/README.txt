displaying the data: the graphical user interface prints that specified grid using Jframe. Furthermore the data from the constraints class are generated to the graphical user interface grid.

editing the data: when the user enters the data the grid is fulfilled with the user input. If the data entered is invalid then an error message would occur.

optional extras:changing the color of the font as well as adding additional buttons for saving,quiting and opening the puzzle. In addition the puzzle also checks the legality as well as returning any errors via error message. 