/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import futoshikipuzzle.Futoshiki;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author esw22
 */
public class Futoshiki1Test {

    Futoshiki filledPuzzle;

    static final String emptyPuzzleString
            = "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                   \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                   \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                   \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                   \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n";

    static final String filledPuzzleString
            = "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                   \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | |>| |\n"
            + "--- --- --- --- ---\n"
            + " V                 \n"
            + "--- --- --- --- ---\n"
            + "| | | | | | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                 ^ \n"
            + "--- --- --- --- ---\n"
            + "| | | |<| | | | | |\n"
            + "--- --- --- --- ---\n"
            + "                 ^ \n"
            + "--- --- --- --- ---\n"
            + "|4|<| | | |<| | | |\n"
            + "--- --- --- --- ---\n";

    @Before
    public void setUp() {
        //sets up a Futoshiki puzzle
        // Note that we implicitly test the constraint setting here
        filledPuzzle = new Futoshiki();
        filledPuzzle.setColumnConstraint(0, 1, ">");
        filledPuzzle.setRowConstraint(4, 0, "<");
        filledPuzzle.setRowConstraint(4, 2, "<");
        filledPuzzle.setColumnConstraint(4, 3, "<");
        filledPuzzle.setColumnConstraint(4, 2, "<");
        filledPuzzle.setRowConstraint(3, 1, "<");
        filledPuzzle.setRowConstraint(1, 3, ">");

        filledPuzzle.setSquare(4, 0, 4);
    }

    @After
    public void tearDown() {
    }

    @Test
    public void settingTest() {
        Futoshiki fs = new Futoshiki(6);
        fs.setSquare(0, 0, 1);
        assertEquals(1, fs.getSquare(0, 0));
        fs.setSquare(0, 0, -1);
        assertEquals(1, fs.getSquare(0, 0));
        // Note we check different coordinates
        fs.setSquare(5, 5, 4);
        assertEquals(4, fs.getSquare(5, 5));
        fs.setSquare(5, 5, 7);
        assertEquals(4, fs.getSquare(5, 5));
        fs.setSquare(6, 6, 3);
        assertEquals(0, fs.getSquare(6, 6));

    }

    @Test
    public void displayStringSmallTest() {
        Futoshiki fs = new Futoshiki(1);
        assertEquals("---\n| |\n---\n", fs.displayString());
    }

    @Test
    public void displayStringTest() {

        Futoshiki fs = new Futoshiki();
        assertEquals(emptyPuzzleString, fs.displayString());

    }

    @Test
    public void printFilledTest() {
        assertEquals(filledPuzzleString, filledPuzzle.displayString());
    }

    @Test
    public void testRandomPuzzle() {
        boolean foundGreater = false;
        boolean foundLesser = false;
        // This is a one off test.  One might argue that this is a random 
        // method, so should be called multiple times.  However, given the
        // fill occupancy used, there are multiple collisions with very
        // high probability
        Futoshiki fs = new Futoshiki(5);
        fs.fillPuzzle(20, 20, 20);

        String s = fs.displayString();
        int[] counter = new int[3];
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '<' || s.charAt(i) == '^') {
                foundLesser = true;
            } else if (s.charAt(i) == '>' || s.charAt(i) == 'V') {
                foundGreater = true;
            }
            switch (s.charAt(i)) {
                case '1':
                case '2':
                case '3':
                case '4':
                case '5': {
                    counter[0]++;
                    break;
                }
                case '<':
                case '>': {
                    counter[1]++;

                    break;
                }
                case 'V':
                case '^': {
                    counter[2]++;
                    break;
                }
            }
        }      
        assertTrue(foundLesser);
        assertTrue(foundGreater);
        for (int count : counter) {
            assertEquals(20, count);
        }

    }
}
