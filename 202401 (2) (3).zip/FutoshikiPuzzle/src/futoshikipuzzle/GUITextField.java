/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


 
 
public class GUITextField implements FocusListener {
    private final int col;
    private final int row;
    private final Boolean isConstraint;
    private final Boolean isEmpty;
    private Boolean isEditable;
    private final Futoshiki futo;
    private final JTextField textField;

    public GUITextField(int col, int row, Futoshiki futo, Boolean constraint, Boolean isEmpty) {
        isEditable = true;
        this.col = col;
        this.row = row;
        this.futo = futo;
        this.isConstraint = constraint;
        this.isEmpty = isEmpty;
        textField = new JTextField("");
        textField.addFocusListener(this);
        Font font = new Font("Arial", Font.BOLD, 20);
        textField.setPreferredSize(new Dimension(50, 50));
        textField.setOpaque(false);
        textField.setHorizontalAlignment(JTextField.CENTER);
        textField.setFont(font);
        if (constraint) {
            textField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        }
    }

    public JTextField getTextField() {
        if (isConstraint) {
            if (row % 2 == 0 && col % 2 != 0 && (col / 2) < 4 && !futo.getColumnConstraint(row / 2, col / 2).getSymbol().equals("")) {
                textField.setText(futo.getColumnConstraint(row / 2, col / 2).getSymbol());
                isEditable = false;
                textField.setForeground(Color.decode("#0000FF"));
                textField.setEditable(false);
            } else if (row % 2 != 0 && col % 2 == 0 && (row / 2) < 4 && !futo.getRowConstraint(col / 2, row / 2).getSymbol().equals("")) {
                textField.setText(futo.getRowConstraint(col / 2, row / 2).getSymbol());
                isEditable = false;
                textField.setForeground(Color.decode("#0000FF"));
                textField.setEditable(false);
            } else {
                textField.setText("");
                isEditable = false;
                textField.setEditable(false);
            }
        } else if (isEmpty) {
            textField.setVisible(false);
        } else {
            textField.setText(futo.getSquare(col / 2, row / 2).getSymbol());
            if (futo.getSquare(col/2, row/2).isFilled()){
                isEditable = false;
                textField.setForeground(Color.decode("#00000"));
                textField.setEditable(false);
            }
        }
        return textField;
    }

    public void updateSquare() {
        if (!isConstraint) {
            if (!futo.getSquare(col / 2, row / 2).isFilled() && !textField.getText().equals("")) {
                futo.setSquare(col / 2, row / 2, Integer.parseInt(textField.getText()));
                System.out.println("Square has been filled");
            } else {
                if (!textField.getText().equals(futo.getSquare(col / 2, row / 2).getSymbol()))
                    futo.getSquare(col / 2, row / 2).setValue(Integer.parseInt(textField.getText()));
            }
        } else if (row % 2 != 0 && col % 2 == 0 && (row / 2) != 4) {
            futo.setRowConstraint(row / 2, col / 2, textField.getText());
            textField.setText(futo.getRowConstraint(row/2, col/2).getSymbol());
        } else if (row % 2 == 0 && col % 2 != 0 && (col / 2) != 4) {
            futo.setColumnConstraint(row / 2, col / 2, textField.getText());
            textField.setText(futo.getColumnConstraint(col/2, row/2).getSymbol());
        }
    }

    @Override
    public void focusGained(FocusEvent e) {
    }
    @Override
    public void focusLost(FocusEvent e) {
        if (isEditable){
            if (!textField.getText().equals("")) {
                if (isConstraint) {
                    if (textField.getText().equals("<") || textField.getText().equals(">")) {
                        updateSquare();
                    } else {
                        JOptionPane.showMessageDialog(null, "Legal entries for constraints are '<' and '>'.");
                        textField.setText("");
                    }
                } else {
                    if (Integer.parseInt(textField.getText()) > 0 && Integer.parseInt(textField.getText()) < 6) {
                        updateSquare();
                    } else {
                        JOptionPane.showMessageDialog(null, "Legal entries for numbers is anything inclusively between 1 and 5.");
                        textField.setText("");
                    }
                }
            } else {
                if (!isConstraint){
                    futo.setEmpty(col/2,row/2);
                }
            }
        }
    }
}