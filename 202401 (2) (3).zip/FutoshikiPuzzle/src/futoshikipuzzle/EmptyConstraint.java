/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futoshikipuzzle;

/**
 *
 * @author 
 */
public class EmptyConstraint extends FutoshikiSquare
{
    public EmptyConstraint()
    {
        //do nothing
    }
    
    @Override
    public String getSymbol()
    {
        return "";
    }

    @Override
    public void setValue(int value) {
    }

    @Override
    public int getValue() {
        return 0;
    }

    public boolean isSatisfied() {
        return true;
    }
    
    @Override
    public boolean isFilled()
    {
        return false;
    }
}

